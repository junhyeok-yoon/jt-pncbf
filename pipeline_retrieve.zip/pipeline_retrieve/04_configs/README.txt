note: run-dir config.yaml IS the resolved (frozen-at-launch) config.
