"""v2.8.2 agree condition — LAUNCHER + config-diff guard (CTRL recipe + the ONE agree term).

Follows the s2_run.py pattern: CLONE the FROZEN CTRL config.yaml (the recorded launch config, immune to any
base_config/exp_config drift) and apply ONLY loss.policy.w_agree. The clone->patched flat diff must be EXACTLY
{loss.policy.w_agree}; ABORT otherwise. run_training is then driven with the SAME kwargs CTRL used
(system quadrotor_3d, seed 42, value_init = the v2.7.6 OC value, n_steps_override 30000), with
load_effective_config monkeypatched to return the patched clone so no drifted base/exp key can leak in.

Also prints a DRIFT DIAGNOSTIC: how the CURRENT base+exp merge (the standard v276 launcher's source) differs
from the recorded CTRL config.yaml — so the Researcher can see whether the standard condition launcher would
still reproduce CTRL.

--dry-run prints the diffs and the run_training re-stamp preview, then exits WITHOUT launching.
This dispatch is PREPARE-ONLY: do NOT run without --dry-run unless the Researcher has seen the S1 gate result.
No setsid, no nohup, no git.
"""
from __future__ import annotations
import argparse, copy, hashlib, os
from pathlib import Path

os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
import yaml

import src.frameworks.jt_pncbf.train as T
from src.frameworks.jt_pncbf.train import run_training, __version__

REPO = Path("/home/junhyeok/MIT/jt-pncbf")
CTRL_CFG = REPO / "data/runs/v2.8.2/set__20260803-063606__seed42/v2.8.2__jt__20260803-063606__seed42/config.yaml"
VINIT = REPO / "data/runs/v2.7.6/set__20260725-043415__seed42/v2.7.6__oc__20260725-043415__seed42/checkpoints/best.pt"


def _flat(d, p=""):
    o = {}
    for k, v in d.items():
        o.update(_flat(v, p + k + ".")) if isinstance(v, dict) else o.__setitem__(p + k, v)
    return o


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--w-agree", type=float, default=3.0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--steps", type=int, default=30000)
    ap.add_argument("--stage", default="full", choices=["smoke", "full"])
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    clone = yaml.safe_load(CTRL_CFG.read_text())

    def _patched():
        c = copy.deepcopy(clone)
        c["loss"]["policy"]["w_agree"] = float(a.w_agree)     # the ONE term; everything else = CTRL recipe
        return c

    # ---- GUARD 1 (dispatch): clone (CTRL recorded config) -> patched must differ by EXACTLY the one term ----
    base = _flat(clone); patched = _flat(_patched())
    diff = {k: (base.get(k), patched.get(k)) for k in sorted(set(base) | set(patched)) if base.get(k) != patched.get(k)}
    allowed = {"loss.policy.w_agree"}
    bad = [k for k in diff if k not in allowed]
    print("=== GUARD 1: CTRL recorded config.yaml  ->  agree launch (clone + w_agree) ===", flush=True)
    for k, (b, p) in diff.items():
        print(f"  [{'OK' if k in allowed else 'ERROR'}] {k}: {b!r} -> {p!r}", flush=True)
    if not diff:
        print("  (no diff — w_agree already present?)", flush=True)
    if bad:
        raise SystemExit(f"ABORT: out-of-scope config keys changed vs CTRL config.yaml: {bad}")
    print("GUARD 1 OK: the only change vs CTRL is loss.policy.w_agree.", flush=True)

    # ---- run_training re-stamp preview: these fields it re-derives; they must match the clone (fresh run-id excepted) ----
    print("\n=== run_training re-stamp check (must match CTRL clone; fresh run-id/timestamp is expected) ===", flush=True)
    vsha8 = hashlib.sha256(VINIT.read_bytes()).hexdigest()[:8] if VINIT.exists() else "MISSING"
    checks = {
        "__version__ == run.version": (__version__, clone["run"].get("version")),
        "seed == run.seed": (a.seed, clone["run"].get("seed")),
        "n_steps_override == run.n_steps_override": (a.steps, clone["run"].get("n_steps_override")),
        "VINIT sha8 == run.value_init_sha8": (vsha8, clone["run"].get("value_init_sha8")),
        "VINIT path == run.value_init_ckpt": (str(VINIT), clone["run"].get("value_init_ckpt")),
    }
    restamp_ok = True
    for name, (got, exp) in checks.items():
        ok = str(got) == str(exp)
        restamp_ok = restamp_ok and ok
        print(f"  [{'OK' if ok else 'WARN'}] {name}: launch={got!r} vs CTRL={exp!r}", flush=True)

    # ---- DRIFT DIAGNOSTIC: current base+exp merge vs CTRL config.yaml (does the standard launcher still match CTRL?) ----
    print("\n=== DRIFT DIAGNOSTIC: current base+exp merge  vs  CTRL config.yaml (informational) ===", flush=True)
    cur = _flat(T.load_effective_config())
    cln = _flat(clone)
    drift = {k for k in set(cur) | set(cln) if cur.get(k) != cln.get(k)}
    # ignore pure run-provenance / timestamp keys
    ignore_pref = ("run.value_init", "run.set_fallback", "run.seed", "run.version", "run.framework",
                   "run.n_steps_override", "run.system", "run.e_label")
    drift_hyper = sorted(k for k in drift if not k.startswith(ignore_pref))
    if not drift_hyper:
        print("  base+exp merge matches CTRL on all hyperparameter keys (standard launcher would reproduce CTRL).", flush=True)
    else:
        print(f"  base+exp has drifted from CTRL on {len(drift_hyper)} hyperparameter key(s):", flush=True)
        for k in drift_hyper:
            print(f"    {k}: base+exp={cur.get(k)!r}  vs  CTRL={cln.get(k)!r}", flush=True)
        print("  -> the CLONE launcher (this script) is used precisely so this drift cannot leak into the run.", flush=True)

    print(f"\nw_agree = {a.w_agree}  |  value_init = {VINIT}  |  seed {a.seed}  steps {a.steps}  stage {a.stage}", flush=True)
    if a.dry_run:
        print("\nDRY-RUN: config diff proven = exactly loss.policy.w_agree. NOT launching.", flush=True)
        raise SystemExit(0)

    if not VINIT.exists():
        raise SystemExit(f"ABORT: value-init checkpoint missing: {VINIT}")
    T.load_effective_config = _patched
    r = run_training(stage=a.stage, system="quadrotor_3d", seed=a.seed,
                     value_init_ckpt=VINIT, n_steps_override=a.steps,
                     output_root=REPO / "data", device="auto")
    print(f"agree DONE run_dir={getattr(r,'run_dir',r)} halt_reason={getattr(r,'halt_reason',None)} "
          f"best_cps={getattr(r,'best_cps',None)}", flush=True)


if __name__ == "__main__":
    main()
