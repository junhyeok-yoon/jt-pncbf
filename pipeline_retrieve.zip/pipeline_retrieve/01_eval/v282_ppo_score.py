"""v2.8.2 — FILTER-FREE three-cell dual scoring of a PPO baseline checkpoint.

Mirrors scripts/analysis/v282_rescore_one.py's three-cell dual standard but BYPASSES the filter: the PPO
baseline has no certificate and no filter, so "the shipped scoring config MINUS the filter" reduces to
policy -> action box -> plant -> outcomes (FilterFreeFramework: identity filter, infeasible == 0, no
projection, no empty_fallback). Same pools, same band terminate/open switch, same terminal, same outcome
predicates as every JT/OC row, so it stays the same comparison.

Cells: gate (canonical/fullscr40, band-terminate) / cps_tilt60 (navcone, band-terminate) / cps_bandopen
(canonical/fullscr40, band-OPEN). band_collision_limit fixed at 4.0 (the pool/floor standard). The terminal
goal_angrate_radius is NOT overridden — it flows from the checkpoint's own config (PPO trained at 0.30).

Per-episode records saved per cell. Additive; writes only under --out-dir. No git.

Usage: v282_ppo_score.py --ckpt PATH --label LBL --pool-canonical P.pkl --pool-navcone N.pkl --out-dir D [--threads 4]
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import traceback
from collections import Counter
from pathlib import Path

import torch


def _collision_split(episode_rows) -> dict:
    causes = Counter(r.get("collision_cause", "") for r in episode_rows if r.get("outcome") == "collision")
    n = max(1, len(episode_rows))
    return {
        "collision_obstacle": causes.get("obstacle", 0) / n,
        "collision_band_lower": causes.get("band_lower", 0) / n,   # floor
        "collision_band_upper": causes.get("band_upper", 0) / n,   # ceiling
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--pool-canonical", required=True)
    ap.add_argument("--pool-navcone", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--eval-batch-size", type=int, default=400)
    a = ap.parse_args()
    torch.set_num_threads(int(a.threads))
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    from src.eval.build_pools import load_pool
    from src.eval.evaluate import evaluate
    from src.frameworks.ppo.filter_free import FilterFreeFramework
    from src.frameworks.ppo.train import load_policy_from_checkpoint

    try:
        system, policy, value, config, ck = load_policy_from_checkpoint(a.ckpt, device=DEV)
        trained_angrate = (config.get("env", {}) or {}).get("goal_angrate_radius", None)
        trained_band = (config.get("env", {}) or {}).get("band_collision_limit", None)
    except Exception as e:
        (out / f"ppo_{a.label}.json").write_text(json.dumps(
            {"label": a.label, "ckpt": a.ckpt, "status": "LOAD_FAILED",
             "error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc().splitlines()[-6:]}, indent=2) + "\n")
        print(f"[{a.label}] LOAD_FAILED: {type(e).__name__}: {e}", flush=True)
        return

    fw = FilterFreeFramework(system, policy, value)

    def run_cell(pool_path, band_terminates, cell):
        cfg = copy.deepcopy(config)
        cfg["env"]["dt"] = 0.05
        cfg["env"]["stuck_window_steps"] = 60
        cfg["env"]["stuck_radius"] = 0.10
        cfg["env"]["band_collision_limit"] = 4.0                 # pool/floor standard, fixed
        cfg["env"]["band_terminates"] = band_terminates
        cfg["eval"]["max_steps"] = 200
        cfg["eval"]["dt_ctrl"] = 0.05
        res = evaluate(fw, load_pool(Path(pool_path)), cfg, mode="final",
                       step=int(ck.get("step", 0)), ckpt_name=a.label, max_scenes=None,
                       include_lqr_baseline=False, eval_batch_size=int(a.eval_batch_size))
        eps = res.episode_rows
        with open(out / f"ppo_{a.label}_{cell}_episodes.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(eps[0].keys()), extrasaction="ignore")
            w.writeheader()
            for e in eps:
                w.writerow(e)
        row = dict(res.eval_row)
        row.update(_collision_split(eps))
        row["_n_episodes"] = len(eps)
        return row

    rep = {"label": a.label, "ckpt": a.ckpt, "status": "OK",
           "framework": "ppo_baseline_no_certificate_no_filter",
           "trained_goal_angrate_radius": (None if trained_angrate is None or
                                           (isinstance(trained_angrate, float) and math.isinf(trained_angrate)) else trained_angrate),
           "trained_band_collision_limit": trained_band, "scored_band_collision_limit": 4.0,
           "pool_canonical": str(a.pool_canonical), "pool_navcone": str(a.pool_navcone),
           "filter": "NONE (identity: policy -> action box -> plant -> outcomes; infeasibility=0 by construction)",
           "n_steps": ck.get("step", None), "iteration": ck.get("iteration", None),
           "env_steps": ck.get("env_steps", None)}
    try:
        rep["gate"] = run_cell(a.pool_canonical, True, "gate")
        rep["cps_tilt60"] = run_cell(a.pool_navcone, True, "cps_tilt60")
        rep["cps_bandopen"] = run_cell(a.pool_canonical, False, "cps_bandopen")
    except Exception as e:
        rep["status"] = "EVAL_FAILED"
        rep["error"] = f"{type(e).__name__}: {e}"
        rep["trace"] = traceback.format_exc().splitlines()[-6:]
        (out / f"ppo_{a.label}.json").write_text(json.dumps(rep, indent=2) + "\n")
        print(f"[{a.label}] EVAL_FAILED: {type(e).__name__}: {e}", flush=True)
        return
    (out / f"ppo_{a.label}.json").write_text(json.dumps(rep, indent=2) + "\n")
    g = rep["gate"]
    print(f"[{a.label}] OK term_angrate={rep['trained_goal_angrate_radius']} "
          f"gate cps={g['cps']:.4f} reach={g['reach']:.4f} coll={g['collision']:.4f} "
          f"(obs {g['collision_obstacle']:.4f}/floor {g['collision_band_lower']:.4f}/ceil {g['collision_band_upper']:.4f}) "
          f"oob={g['oob']:.4f} stuck={g['stuck']:.4f} timeout={g['timeout']:.4f} infeas={g['infeasibility']:.4f} "
          f"| tilt60 cps={rep['cps_tilt60']['cps']:.4f} | bandopen cps={rep['cps_bandopen']['cps']:.4f}", flush=True)


if __name__ == "__main__":
    main()
