"""v2.8.2 S1 GATE — pi-vs-filter discrepancy hypothesis (eval-only, HARD GATE, no training).

Scores CTRL and the recorded v2.7.6 leader on the GATE CELL exactly as scripts/analysis/v282_rescore_one.py
does (canonical fullscr40 pool, band-terminate, shipped empty_fallback {kstep, phases 1, k 3}, projection
dual_solve, terminal flows from each ckpt's own trained config). For every episode it records the per-step
normalized discrepancy d_t = ||pi(x_t) - u_filt(x_t)|| / box_range, where pi = raw policy action (u_nom) and
u_filt = HardNet-filtered applied action (u_safe) -- BOTH taken straight from the deployed rollout (no filter
recompute). box_range = f_rotor_max - f_rotor_min (action box width).

The TRUE empty-branch flag is captured from the filter's OWN indicator (framework._filter.last_empty) via a
wrapper on framework.filter, NOT via evaluate()'s result.empty (which aliases to `infeasible` because the eval
rollout's _fobj handle is None -- the KNOWN BUG). last_singular is captured the same way. Discrepancy numbers
never touch the aliased path.

S1 measurements: (1) discrepancy distribution by outcome (reach/collision/timeout) and within-episode phase;
(2) same-scene confound control (CTRL timeout & leader reach); (3) true empty-step fraction by outcome.

Additive, writes only under --out-dir. No git.
"""
from __future__ import annotations
import argparse, copy, json, math, os
from pathlib import Path

os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
import numpy as np
import torch

REPO = Path("/home/junhyeok/MIT/jt-pncbf")
CTRL = REPO / "data/runs/v2.8.2/set__20260803-063606__seed42/v2.8.2__jt__20260803-063606__seed42/checkpoints/best.pt"
LEADER = REPO / "data/runs/v2.7.6/set__20260725-043415__seed42/v2.7.6__jt__20260725-052127__seed42/checkpoints/best.pt"
POOL = REPO / "data/secured_data/pools/eval_fullscr40_quadrotor-3d-d2r_n2000_seed623456.pkl"
MAX_STEPS = 200


def gate_overrides(ckpt_path: Path) -> dict:
    """Exactly v282_rescore_one.run_cell(gate): canonical pool, band_terminates=True."""
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    filt = copy.deepcopy(ck["config"]["filter"])
    filt["empty_fallback"] = {"mode": "kstep", "phases": 1, "k": 3}
    filt["projection"] = filt.get("projection") or "dual_solve"
    over = {
        "env": {"dt": 0.05, "stuck_window_steps": 60, "stuck_radius": 0.10,
                "band_collision_limit": 4.0, "band_terminates": True},
        "eval": {"max_steps": MAX_STEPS, "dt_ctrl": 0.05},
        "filter": filt,
    }
    return over


def score_and_capture(ckpt_path: Path, label: str, pool, eval_batch_size: int, dev, max_scenes=None):
    from src.frameworks.jt_pncbf.train import load_framework_from_checkpoint
    from src.eval.evaluate import evaluate

    over = gate_overrides(ckpt_path)
    fw, cfg, ck2 = load_framework_from_checkpoint(ckpt_path, config_overrides=over)
    for n in ("value_net", "policy_net"):
        m = getattr(fw, n, None)
        if m is not None:
            m.to(dev)

    # box_range = action box width (uniform across rotors); assert uniform
    bounds = fw.system.u_bounds
    widths = (bounds[:, 1] - bounds[:, 0]).tolist()
    assert max(widths) - min(widths) < 1e-9, f"non-uniform action box: {widths}"
    box_range = float(widths[0])

    # --- capture the TRUE empty/singular flags from the filter's own indicator ---
    calls = []  # list of (empty_np[Bb], singular_np[Bb]) in call order
    orig_filter = fw.filter

    def wrapped_filter(x, u_nom, scene):
        out = orig_filter(x, u_nom, scene)
        le = getattr(fw._filter, "last_empty", None)
        ls = getattr(fw._filter, "last_singular", None)
        infeas = out[1]
        e = (le.detach().to("cpu").bool().numpy() if le is not None
             else infeas.detach().to("cpu").bool().numpy())
        s = (ls.detach().to("cpu").bool().numpy() if ls is not None
             else np.zeros(infeas.shape[0], dtype=bool))
        calls.append((e, s, le is not None))
        return out

    fw.filter = wrapped_filter

    res = evaluate(fw, pool, cfg, mode="final", step=int(ck2.get("step", 0)),
                   ckpt_name=label, max_scenes=max_scenes, include_lqr_baseline=False,
                   eval_batch_size=eval_batch_size)

    N = len(res.episode_rows)
    eff_ang = cfg["env"].get("goal_angrate_radius", None)
    eval_row = {k: (float(v) if isinstance(v, (int, float)) else v) for k, v in res.eval_row.items()}
    print(f"[{label}] eval cps={res.eval_row['cps']:.4f} reach={res.eval_row['reach']:.4f} "
          f"coll={res.eval_row['collision']:.4f} timeout={res.eval_row['timeout']:.4f} "
          f"stuck={res.eval_row['stuck']:.4f} oob={res.eval_row['oob']:.4f} "
          f"infeas={res.eval_row['infeasibility']:.4f} n={N} term_angrate={eff_ang}", flush=True)

    # reconstruct TRUE empty/singular [N, T]
    n_batches = math.ceil(N / eval_batch_size)
    assert len(calls) == n_batches * MAX_STEPS, (len(calls), n_batches, MAX_STEPS)
    empty_full = np.zeros((N, MAX_STEPS), dtype=bool)
    sing_full = np.zeros((N, MAX_STEPS), dtype=bool)
    empty_captured = all(c[2] for c in calls)
    for b in range(n_batches):
        base = b * MAX_STEPS
        lo = b * eval_batch_size
        hi = min(lo + eval_batch_size, N)
        for t in range(MAX_STEPS):
            e, s, _ = calls[base + t]
            empty_full[lo:hi, t] = e[: hi - lo]
            sing_full[lo:hi, t] = s[: hi - lo]

    # per-episode arrays
    outcome = np.array([r["outcome"] for r in res.episode_rows], dtype=object)
    n_steps = np.array([int(r["n_steps"]) for r in res.episode_rows], dtype=np.int64)
    infeas_frac = np.array([float(r["infeasible_step_frac"]) for r in res.episode_rows])
    empty_frac_aliased = np.array([float(r["empty_step_frac"]) for r in res.episode_rows])

    PHYS = {"goal", "collision", "oob"}
    active = np.where(np.isin(outcome, list(PHYS)), n_steps, MAX_STEPS).astype(np.int64)
    active = np.clip(active, 0, MAX_STEPS)

    disc = np.full((N, MAX_STEPS), np.nan, dtype=np.float64)          # per-step normalized discrepancy
    goal_dist = np.full((N, MAX_STEPS), np.nan, dtype=np.float64)
    dmean = np.full(N, np.nan); dmax = np.full(N, np.nan)
    dmean_appr = np.full(N, np.nan); dmean_term = np.full(N, np.nan)     # fractional 2/3 | 1/3 split
    dmean_preC = np.full(N, np.nan); dmean_postC = np.full(N, np.nan)    # closest-approach split
    empty_frac_true = np.full(N, np.nan); sing_frac_true = np.full(N, np.nan)

    for e in range(N):
        traj = res.trajectories[e]
        un = traj.filtered.u_nom[:, 0, :]
        us = traj.filtered.u_safe[:, 0, :]
        d = (torch.linalg.norm(us - un, dim=-1) / box_range).detach().to("cpu").numpy()
        disc[e, : d.shape[0]] = d
        pos = fw.system.position(traj.filtered.states[:, 0, :]).detach().to("cpu").numpy()
        goal = np.asarray(traj.scene.goal, dtype=np.float64)
        gd = np.linalg.norm(pos[:, : goal.shape[0]] - goal, axis=-1)
        goal_dist[e, : min(gd.shape[0], MAX_STEPS)] = gd[:MAX_STEPS]
        A = int(active[e])
        if A <= 0:
            continue
        da = disc[e, :A]
        dmean[e] = float(np.nanmean(da)); dmax[e] = float(np.nanmax(da))
        empty_frac_true[e] = float(empty_full[e, :A].mean())
        sing_frac_true[e] = float(sing_full[e, :A].mean())
        cut = int(round((2.0 / 3.0) * A))
        if cut > 0:
            dmean_appr[e] = float(np.nanmean(da[:cut]))
        if cut < A:
            dmean_term[e] = float(np.nanmean(da[cut:A]))
        # closest approach within active window (states 0..A-1 correspond to actions 0..A-1)
        cstep = int(np.nanargmin(gd[:A])) if A >= 1 else 0
        if cstep > 0:
            dmean_preC[e] = float(np.nanmean(da[:cstep]))
        dmean_postC[e] = float(np.nanmean(da[cstep:A]))

    del res
    if dev.type == "cuda":
        torch.cuda.empty_cache()

    return {
        "label": label, "ckpt": str(ckpt_path), "box_range": box_range,
        "n": N, "outcome": outcome, "active": active, "n_steps": n_steps,
        "dmean": dmean, "dmax": dmax, "dmean_appr": dmean_appr, "dmean_term": dmean_term,
        "dmean_preC": dmean_preC, "dmean_postC": dmean_postC,
        "empty_frac_true": empty_frac_true, "sing_frac_true": sing_frac_true,
        "infeas_frac": infeas_frac, "empty_frac_aliased": empty_frac_aliased,
        "empty_captured": bool(empty_captured),
        "term_angrate": (None if eff_ang is None or (isinstance(eff_ang, float) and math.isinf(eff_ang)) else float(eff_ang)),
        "disc": disc, "goal_dist": goal_dist, "eval_row": eval_row,
    }


def grp_stats(vals):
    v = np.asarray(vals, dtype=np.float64)
    v = v[np.isfinite(v)]
    if v.size == 0:
        return {"n": 0, "mean": None, "median": None, "p90": None, "std": None}
    return {"n": int(v.size), "mean": float(v.mean()), "median": float(np.median(v)),
            "p90": float(np.percentile(v, 90)), "std": float(v.std())}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=str(REPO / "data/runs/v2.8.2/agree_gate"))
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--eval-batch-size", type=int, default=400)
    ap.add_argument("--max-scenes", type=int, default=None)
    a = ap.parse_args()
    torch.set_num_threads(int(a.threads))
    out = Path(a.out_dir); out.mkdir(parents=True, exist_ok=True)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    from src.eval.build_pools import load_pool, sha256_file
    pool_sha = sha256_file(POOL)
    print(f"pool sha256 prefix {pool_sha[:8]} (expect 588a2724)", flush=True)
    pool = load_pool(POOL)
    print(f"pool n_scenes = {len(pool.scenes)}", flush=True)

    ctrl = score_and_capture(CTRL, "CTRL", pool, a.eval_batch_size, dev, max_scenes=a.max_scenes)
    leader = score_and_capture(LEADER, "LEADER", pool, a.eval_batch_size, dev, max_scenes=a.max_scenes)

    # save raw arrays
    for r in (ctrl, leader):
        np.savez_compressed(
            out / f"arrays_{r['label']}.npz",
            outcome=r["outcome"].astype("U16"), active=r["active"], n_steps=r["n_steps"],
            dmean=r["dmean"], dmax=r["dmax"], dmean_appr=r["dmean_appr"], dmean_term=r["dmean_term"],
            dmean_preC=r["dmean_preC"], dmean_postC=r["dmean_postC"],
            empty_frac_true=r["empty_frac_true"], sing_frac_true=r["sing_frac_true"],
            infeas_frac=r["infeas_frac"], empty_frac_aliased=r["empty_frac_aliased"],
            disc=r["disc"].astype(np.float32), goal_dist=r["goal_dist"].astype(np.float32),
            box_range=np.array([r["box_range"]]),
        )

    def by_outcome(r):
        o = r["outcome"]
        d = {}
        for grp, mask in (("reach", o == "goal"), ("collision", o == "collision"),
                          ("timeout", o == "timeout"), ("stuck", o == "stuck"), ("oob", o == "oob")):
            idx = np.where(mask)[0]
            d[grp] = {
                "count": int(idx.size),
                "disc_mean_active": grp_stats(r["dmean"][idx]),
                "disc_max_active": grp_stats(r["dmax"][idx]),
                "disc_approach_2of3": grp_stats(r["dmean_appr"][idx]),
                "disc_terminal_1of3": grp_stats(r["dmean_term"][idx]),
                "disc_pre_closest": grp_stats(r["dmean_preC"][idx]),
                "disc_post_closest": grp_stats(r["dmean_postC"][idx]),
                "empty_frac_true": grp_stats(r["empty_frac_true"][idx]),
                "singular_frac_true": grp_stats(r["sing_frac_true"][idx]),
                "empty_frac_aliased": grp_stats(r["empty_frac_aliased"][idx]),
                "infeas_frac": grp_stats(r["infeas_frac"][idx]),
            }
        # success vs failure aggregate
        succ = np.where(o == "goal")[0]
        fail = np.where((o == "collision") | (o == "timeout") | (o == "oob") | (o == "stuck"))[0]
        d["_success"] = {"count": int(succ.size), "disc_mean_active": grp_stats(r["dmean"][succ])}
        d["_failure"] = {"count": int(fail.size), "disc_mean_active": grp_stats(r["dmean"][fail])}
        d["_failure_timeoutcoll"] = grp_stats(r["dmean"][np.where((o == "collision") | (o == "timeout"))[0]])
        return d

    ctrl_bo = by_outcome(ctrl)
    leader_bo = by_outcome(leader)

    # ---------------- CONFOUND CONTROL: CTRL timeout & LEADER reach, same scene ----------------
    oc = ctrl["outcome"]; ol = leader["outcome"]
    ctrl_timeout = oc == "timeout"
    leader_reach = ol == "goal"
    confound_idx = np.where(ctrl_timeout & leader_reach)[0]
    ctrl_to_all = np.where(ctrl_timeout)[0]
    cf = {
        "n_ctrl_timeout": int(ctrl_to_all.size),
        "n_ctrl_timeout_leader_reach": int(confound_idx.size),
        "n_ctrl_timeout_leader_also_fail": int(np.where(ctrl_timeout & ~leader_reach)[0].size),
    }
    if confound_idx.size > 0:
        c_d = ctrl["dmean"][confound_idx]
        l_d = leader["dmean"][confound_idx]
        c_dt = ctrl["dmean_term"][confound_idx]
        l_dt = leader["dmean_term"][confound_idx]
        both = np.isfinite(c_d) & np.isfinite(l_d)
        paired = np.where(both)[0]
        cf["ctrl_disc_on_confound"] = grp_stats(c_d)
        cf["leader_disc_on_confound"] = grp_stats(l_d)
        cf["ctrl_disc_terminal_on_confound"] = grp_stats(c_dt)
        cf["leader_disc_terminal_on_confound"] = grp_stats(l_dt)
        if paired.size > 0:
            diff = c_d[both] - l_d[both]   # positive => CTRL larger (leader lower)
            cf["paired_n"] = int(paired.size)
            cf["paired_mean_ctrl_minus_leader"] = float(diff.mean())
            cf["paired_median_ctrl_minus_leader"] = float(np.median(diff))
            cf["frac_scenes_leader_lower"] = float((diff > 0).mean())
            cf["paired_ctrl_mean"] = float(c_d[both].mean())
            cf["paired_leader_mean"] = float(l_d[both].mean())
            cf["leader_over_ctrl_ratio"] = float(l_d[both].mean() / c_d[both].mean()) if c_d[both].mean() else None

    # ---------------- GATE RULE ----------------
    succ_mean = ctrl_bo["_success"]["disc_mean_active"]["mean"]
    fail_mean = ctrl_bo["_failure_timeoutcoll"]["mean"]
    cond1 = (fail_mean is not None and succ_mean is not None and fail_mean > succ_mean)
    # cond2: leader materially lower than CTRL on same-scene confound
    ratio = cf.get("leader_over_ctrl_ratio", None)
    frac_lower = cf.get("frac_scenes_leader_lower", None)
    # "materially lower" => leader mean clearly below CTRL (ratio < ~0.85) AND most scenes lower
    cond2 = (ratio is not None and ratio < 0.85 and frac_lower is not None and frac_lower > 0.5)
    verdict = "PASS" if (cond1 and cond2) else "FAIL"

    summary = {
        "verdict": verdict,
        "gate_rule": "PASS iff (failure disc > success disc on CTRL) AND (leader materially lower on same-scene confound)",
        "cond1_failure_gt_success": bool(cond1),
        "cond1_ctrl_success_disc_mean": succ_mean,
        "cond1_ctrl_failure_disc_mean_timeoutcoll": fail_mean,
        "cond2_confound_leader_materially_lower": bool(cond2),
        "cond2_leader_over_ctrl_ratio": ratio,
        "cond2_frac_scenes_leader_lower": frac_lower,
        "cond2_criterion": "ratio < 0.85 AND frac_scenes_leader_lower > 0.5",
        "box_range": ctrl["box_range"],
        "empty_captured_true_indicator": {"CTRL": ctrl["empty_captured"], "LEADER": leader["empty_captured"]},
        "CTRL": {"ckpt": ctrl["ckpt"], "term_angrate": ctrl["term_angrate"], "eval_row": ctrl["eval_row"], "by_outcome": ctrl_bo},
        "LEADER": {"ckpt": leader["ckpt"], "term_angrate": leader["term_angrate"], "eval_row": leader["eval_row"], "by_outcome": leader_bo},
        "confound_control": cf,
    }
    (out / "gate_summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")

    print("\n================ S1 GATE VERDICT ================", flush=True)
    print(f"VERDICT: {verdict}", flush=True)
    print(f"cond1 (CTRL failure>success disc): {cond1}  success={succ_mean}  failure(to+coll)={fail_mean}", flush=True)
    print(f"cond2 (leader materially lower on confound): {cond2}  ratio={ratio}  frac_lower={frac_lower}", flush=True)
    print(json.dumps(cf, indent=2, default=str), flush=True)
    print("wrote", out / "gate_summary.json", flush=True)


if __name__ == "__main__":
    main()
