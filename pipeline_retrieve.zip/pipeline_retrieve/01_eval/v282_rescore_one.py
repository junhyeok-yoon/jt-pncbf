"""v2.8.2 pool-rebuild — re-score ONE quadrotor_3d checkpoint on the three-cell dual standard against CHOSEN pools.

Cells: gate (canonical pool, band-terminate) / cps_tilt60 (navcone pool, band-terminate) / cps_bandopen (canonical
pool, band-OPEN). Shipped fallback {kstep, phases 1, k 3}; projection dual_solve. band_collision_limit=4.0 is the
FLOOR/pool standard (the pools are screened at 4.0) and is fixed for every checkpoint. The SETTLING terminal
goal_angrate_radius is NOT overridden — it flows from the checkpoint's own trained config, so each checkpoint is
scored "at the terminal it was trained at" (v2.8.2->0.30, v2.8.0->0.48, pre-terminal v2.7.x-> absent => inf).

Per-episode records saved per cell. Load failure is reported as status=LOAD_FAILED, never substituted. CPU threads
set by --threads. GPU for the nets. Additive; writes only under --out-dir. No git.

Usage: v282_rescore_one.py --ckpt PATH --label LBL --pool-canonical P.pkl --pool-navcone N.pkl --out-dir D [--threads 4]"""
from __future__ import annotations
import argparse, copy, csv, json, math, os, traceback
from pathlib import Path
import torch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--pool-canonical", required=True)
    ap.add_argument("--pool-navcone", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--eval-batch-size", type=int, default=400)   # chunk the GPU rollout to cap VRAM for concurrency
    a = ap.parse_args()
    torch.set_num_threads(int(a.threads))
    out = Path(a.out_dir); out.mkdir(parents=True, exist_ok=True)
    DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # read trained terminal from the checkpoint's OWN config (band flows for record; angrate flows into scoring)
    try:
        ck = torch.load(a.ckpt, map_location="cpu", weights_only=False)
        env0 = ck.get("config", {}).get("env", {}) or {}
        trained_angrate = env0.get("goal_angrate_radius", None)         # None => absent => inf terminal
        trained_band = env0.get("band_collision_limit", None)
    except Exception as e:
        (out / f"dual_{a.label}.json").write_text(json.dumps(
            {"label": a.label, "ckpt": a.ckpt, "status": "LOAD_FAILED",
             "stage": "torch.load", "error": f"{type(e).__name__}: {e}"}, indent=2) + "\n")
        print(f"[{a.label}] LOAD_FAILED at torch.load: {type(e).__name__}: {e}", flush=True)
        return

    from src.eval.evaluate import evaluate
    from src.eval.run_full import _load_framework as load_fw
    from src.eval.build_pools import load_pool

    def run_cell(pool_path, band_terminates, cell):
        filt = copy.deepcopy(ck["config"]["filter"])
        filt["empty_fallback"] = {"mode": "kstep", "phases": 1, "k": 3}
        filt["projection"] = filt.get("projection") or "dual_solve"
        # band_collision_limit fixed at 4.0 (floor/pool standard). goal_angrate_radius NOT set -> flows from ckpt.
        over = {"env": {"dt": 0.05, "stuck_window_steps": 60, "stuck_radius": 0.10,
                        "band_collision_limit": 4.0, "band_terminates": band_terminates},
                "eval": {"max_steps": 200, "dt_ctrl": 0.05}, "filter": filt}
        fw, cfg, ck2 = load_fw(a.ckpt, config_overrides=over)
        for n in ("value_net", "policy_net"):
            mnet = getattr(fw, n, None)
            if mnet is not None:
                mnet.to(DEV)
        res = evaluate(fw, load_pool(Path(pool_path)), cfg, mode="final",
                       step=int(ck2.get("step", 0)), ckpt_name=a.label,
                       max_scenes=None, include_lqr_baseline=False,
                       eval_batch_size=int(a.eval_batch_size))
        eps = res.episode_rows
        with open(out / f"dual_{a.label}_{cell}_episodes.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(eps[0].keys()), extrasaction="ignore")
            w.writeheader()
            for e in eps:
                w.writerow(e)
        eff_ang = cfg["env"].get("goal_angrate_radius", None)
        row = dict(res.eval_row)
        row["_effective_goal_angrate_radius"] = (None if eff_ang is None or (isinstance(eff_ang, float) and math.isinf(eff_ang)) else float(eff_ang))
        row["_n_episodes"] = len(eps)
        return row

    rep = {"label": a.label, "ckpt": a.ckpt, "status": "OK",
           "trained_goal_angrate_radius": (None if trained_angrate is None or (isinstance(trained_angrate, float) and math.isinf(trained_angrate)) else trained_angrate),
           "trained_band_collision_limit": trained_band,
           "scored_band_collision_limit": 4.0,
           "pool_canonical": str(a.pool_canonical), "pool_navcone": str(a.pool_navcone),
           "fallback": "kstep phases1 k3", "projection": "dual_solve"}
    try:
        rep["gate"] = run_cell(a.pool_canonical, True, "gate")
        rep["cps_tilt60"] = run_cell(a.pool_navcone, True, "cps_tilt60")
        rep["cps_bandopen"] = run_cell(a.pool_canonical, False, "cps_bandopen")
    except Exception as e:
        rep["status"] = "LOAD_FAILED"
        rep["error"] = f"{type(e).__name__}: {e}"
        rep["trace"] = traceback.format_exc().splitlines()[-6:]
        (out / f"dual_{a.label}.json").write_text(json.dumps(rep, indent=2) + "\n")
        print(f"[{a.label}] LOAD_FAILED: {type(e).__name__}: {e}", flush=True)
        return
    (out / f"dual_{a.label}.json").write_text(json.dumps(rep, indent=2) + "\n")
    g = rep["gate"]
    print(f"[{a.label}] OK term_angrate={rep['trained_goal_angrate_radius']} "
          f"gate cps={g['cps']:.4f} reach={g['reach']:.4f} coll={g['collision']:.4f} infeas={g['infeasibility']:.4f} "
          f"| tilt60 cps={rep['cps_tilt60']['cps']:.4f} | bandopen cps={rep['cps_bandopen']['cps']:.4f}", flush=True)


if __name__ == "__main__":
    main()
