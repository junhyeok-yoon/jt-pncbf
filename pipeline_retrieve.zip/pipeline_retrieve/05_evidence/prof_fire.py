"""Profile ONE JT in-loop eval fire (CTRL, HardNet dual_solve) to locate the real bottleneck.
Tests the dispatch claim: '89.6% in 4096 sequential proxsuite QPs, 1.1 cores'."""
import cProfile, pstats, sys, time, os
from pathlib import Path
sys.path.insert(0, "scripts/analysis")
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
import torch
import v282_agree_gate as G
from src.eval.build_pools import load_pool
from src.frameworks.jt_pncbf.train import load_framework_from_checkpoint
from src.eval.evaluate import evaluate

CTRL = Path("data/runs/v2.8.2/set__20260803-063606__seed42/v2.8.2__jt__20260803-063606__seed42/checkpoints/best.pt")
NSC = 256
over = G.gate_overrides(CTRL)
fw, cfg, ck = load_framework_from_checkpoint(CTRL, config_overrides=over)
# device the eval actually runs on = device of the framework's params
dev = None
for n in ("value_net", "policy_net"):
    m = getattr(fw, n, None)
    if m is not None:
        dev = next(m.parameters()).device
        break
print(f"eval device (framework params): {dev}")
pool = load_pool(G.POOL)

pr = cProfile.Profile()
torch.set_num_threads(torch.get_num_threads())
t0 = time.time()
pr.enable()
res = evaluate(fw, pool, cfg, mode="in_loop", step=0, ckpt_name="prof",
               max_scenes=NSC, include_lqr_baseline=False, eval_batch_size=NSC)
pr.disable()
dt = time.time() - t0
print(f"\n=== {NSC} scenes: {dt:.1f}s  -> extrapolated 2000: {dt*2000/NSC:.1f}s  (torch_threads={torch.get_num_threads()}) ===")
st = pstats.Stats(pr)
st.sort_stats("tottime")
print("\n--- TOP 15 by TOTTIME (self time) ---")
st.print_stats(15)
# explicit checks
import io as _io
buf = _io.StringIO(); st2 = pstats.Stats(pr, stream=buf); st2.print_stats(); s = buf.getvalue()
print("proxsuite in profile:", "proxsuite" in s.lower())
print("_exact_dual in profile:", "_exact_dual" in s)
print("rk4 in profile:", "rk4" in s.lower())
