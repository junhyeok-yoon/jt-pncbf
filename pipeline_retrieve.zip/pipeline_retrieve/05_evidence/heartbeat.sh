#!/bin/bash
AG=data/runs/v2.8.2/set__20260805-102541__seed42/v2.8.2__jt__20260805-102541__seed42
PPO=data/runs/v2.8.2/ppo_baseline/v2.8.2__ppo__20260805-102649__seed42
HB=/tmp/claude-1000/-home-junhyeok-MIT-jt-pncbf/31d93785-ac11-4206-bf50-a4c3de145dff/scratchpad/heartbeat.log
AGREE=3210519; REV12=3213396
for i in $(seq 1 720); do
  ts=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
  astep=$(python3 -c "import json;print(json.load(open('$AG/status.json'))['current_step'])" 2>/dev/null || echo NA)
  aalive=$(ps -p $AGREE >/dev/null 2>&1 && echo up || echo DOWN)
  pstep=$(tail -40 "$PPO/../"*/*.log 2>/dev/null; grep -oE 'iter [0-9]+/3000' "/tmp/claude-1000/-home-junhyeok-MIT-jt-pncbf/31d93785-ac11-4206-bf50-a4c3de145dff/scratchpad/heartbeat.log" >/dev/null 2>&1; true)
  piter=$(tail -1 "$PPO/metrics.csv" 2>/dev/null | cut -d, -f1)
  palive=$(ps -p $REV12 >/dev/null 2>&1 && echo up || echo DOWN)
  echo "$ts | agree($aalive) step=$astep | ppo($palive) iter=$piter" >> "$HB"
  if [ "$aalive" = DOWN ] && [ "$palive" = DOWN ]; then echo "$ts | both DOWN, heartbeat exiting" >> "$HB"; break; fi
  sleep 30
done
